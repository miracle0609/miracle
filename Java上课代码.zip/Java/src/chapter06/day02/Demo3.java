package chapter06.day02;

import java.util.TreeSet;

import java.util.ArrayList;
import java.util.Iterator;


public class Demo3 {
public static void main(String[] args) {
	TreeSet<Integer> set=new TreeSet<Integer>();
	set.add(1);
	set.add(2);
	set.add(23);
	set.add(3);
	System.out.println(set);
	//��ȡ��Ԫ��
	System.out.println(set.first());
	//��ȡβԪ��
	System.out.println(set.last());
	//����С�ڻ����4�����Ԫ��
	System.out.println(set.floor(4));
	//ɾ�������е�һ��Ԫ�ز��ҷ���ֵ
	System.out.println(set.pollFirst());
	System.out.println("==========");

	
	TreeSet<String> set1=new TreeSet<String>();
	set1.add("11");
	set1.add("10");
	set1.add("21");
	set1.add("211");
	System.out.println(set1);
	System.out.println(set1.size());
	
	System.out.println("==========");
	/*for(Object obj:set) {
		System.out.println(obj);
	}
	System.out.println("==========");
	//��һ��
	Iterator it = set.iterator();
	while (it.hasNext()) {
		Object obj = it.next();
		System.out.println(obj);
	}
	System.out.println("==========");
	//�ڶ���
	Iterator<Integer> it1 = set.iterator();
	while (it1.hasNext()) {
		Integer str = it1.next();
		System.out.println(str);
	}*/
}
}
