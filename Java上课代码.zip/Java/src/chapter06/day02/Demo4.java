package chapter06.day02;

import java.util.Comparator;
import java.util.TreeSet;

class Person implements Comparable<Object> {
	private String name;
	private int age;
	private String address;

	public Person(String name, int age, String address) {
		super();
		this.name = name;
		this.age = age;
		this.address = address;
	}
	// compareTo����ͨ������ֵ>0�� =�ȣ� <0(1,0,-1)
	@Override
	public int compareTo(Object obj) {
		// TODO Auto- generated method stub
		Person p = (Person) obj;
		if (this.age > p.age) {
			return 1;
		}
		if (this.age == p.age) {
			return this.name.compareTo(p.name);
		}
		return -1;
	}

	public String toString() {
		// TODO Auto-generated method stub
		return name + ":" + age + ":" + address;
	}

	

}

public class Demo4 {
	public static void main(String[] args) {
		TreeSet<Person> set = new TreeSet<Person>();
		set.add(new Person("Jack", 25, "����"));
		set.add(new Person("Tom", 21, "������"));
		set.add(new Person("Rose", 22, "��ľ˹"));
		set.add(new Person("Tom", 21, "ĵ����"));
		set.add(new Person("Frank", 21, "�������"));
		System.out.println(set);	
		
	}
}
