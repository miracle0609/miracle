package chapter06.day02;

import java.util.Comparator;
import java.util.TreeSet;
// 
class Teacher implements Comparable<Object>{
	private String name;
	private int age;

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public int getAge() {
		return age;
	}

	public void setAge(int age) {
		this.age = age;
	}

	public Teacher(String name, int age) {
		super();
		this.name = name;
		this.age = age;
	}
	// compareTo����ͨ������ֵ>0�� =�ȣ� <0(1,0,-1)

	public String toString() {
		// TODO Auto-generated method stub
		return name + ":" + age;
	}

	@Override
	public int compareTo(Object o) {
		// TODO Auto-generated method stub
		return 0;
	}
}

public class Demo6 {
	public static void main(String[] args) {
		TreeSet<Teacher> set = new TreeSet<Teacher>(new Comparator<Teacher>() {
			@Override
			public int compare(Teacher p1, Teacher p2) {
				// TODO Auto-generated method stub
				if (p1.getAge() > p2.getAge()) {
					return 1;
				}
				if (p1.getAge() == p2.getAge()) {
					return p1.getName().compareTo(p2.getName());
				}
				return -1;
			}
		});
		set.add(new Teacher("Jack", 25));
		set.add(new Teacher("Tom", 21));
		set.add(new Teacher("Rose", 22));
		set.add(new Teacher("Tom", 21));
		set.add(new Teacher("Frank", 21));
		System.out.println(set);

	}
}

