package chapter06.day02;

import java.util.HashSet;

class Student {
	String name;
	String id;

	public Student(String name, String id) {
		this.name = name;
		this.id = id;
	}

	public String toString() {
		return id + ":" + name;
	}

	public int hashCode() {
		return this.id.hashCode();
	}

	public boolean equals(Object obj) {
		if (this == obj) {
			return true;
		}
		if (!(obj instanceof Student)) {
			return false;
		}
		Student stu = (Student) obj;
		boolean flag = this.id.equals(stu.id);
		return flag;
	}
}

public class Demo2 {
	public static void main(String[] args) {
		HashSet<Student> set = new HashSet<Student>();
		Student stu1 = new Student("Jack", "5");
		Student stu2 = new Student("Mike", "1");
		Student stu3 = new Student("Alice", "3");
		Student stu4 = new Student("Rose", "3");
		set.add(stu1);
		set.add(stu2);
		set.add(stu3);
		set.add(stu4);
		System.out.println(set);
	}
}
