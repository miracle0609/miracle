package chapter06.day02;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.Iterator;

public class Demo1 {
public static void main(String[] args) {
	HashSet<String> set=new HashSet<>();
	set.add("1");
	set.add("2");
	set.add("3");
	set.add("3");
	System.out.println(set);
	System.out.println("==========");
	
	ArrayList <String> list = new ArrayList<String>(set);
	System.out.println(list.get(0));
	System.out.println("==========");
	
	/*for(Object obj:set) {
		System.out.println(obj);
	}
	System.out.println("==========");
	//��һ��
	Iterator it = set.iterator();
	while (it.hasNext()) {
		Object obj = it.next();
		System.out.println(obj);
	}
	System.out.println("==========");
	//�ڶ���
	Iterator<String> it1 = set.iterator();
	while (it1.hasNext()) {
		String str = it1.next();
		System.out.println(str);
	}*/
}
}
