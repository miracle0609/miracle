package chapter06.day02;

import java.util.Comparator;
import java.util.TreeSet;

class MyCompare implements Comparator<Object> {
	@Override
	public int compare(Object obj1, Object obj2) {
		// TODO Auto generated method stub
		String s1 = (String) obj1;
		String s2 = (String) obj2;
		return s1.length() - s2.length();
	}
}

public class Demo5 {
	public static void main(String[] args) {//
		TreeSet<String> set = new TreeSet<String>(new MyCompare());
		set.add("Jack");
		set.add("Tom");
		set.add("frank");
		set.add("Rose");
		System.out.println(set);
		
		//����2 :�����ڲ���
		TreeSet<String> set1=new TreeSet<String>(new Comparator<Object>(){
		@Override 
		public int compare(Object obj1,Object obj2){
			// TODO  Auto-generated method stub
			String s1=(String)obj1;
			String s2=(String)obj2;
			return s1.length()-s2.length();}
		});
		set1.add("Jack");
		set1.add("Tom");
		set1.add("Rose");
		System.out.println(set1);
		
	}
}
