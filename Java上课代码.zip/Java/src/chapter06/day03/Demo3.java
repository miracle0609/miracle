package chapter06.day03;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.util.Iterator;
import java.util.Properties;
import java.util.Set;

public class Demo3 {
	public static void main(String[] args) throws Exception {
		Properties pps = new Properties();
		// ����test.properties�ļ�
		pps.load(new FileInputStream("test.properties"));
		System.out.println(pps);
		Set set = pps.keySet();
		Iterator it = set.iterator();
		while (it.hasNext()) {
			String key = (String) it.next();
			String value = (String) pps.get(key);
			System.out.println(key + ":" + value);
		}
		FileOutputStream out = new FileOutputStream("test.properties");
		pps.setProperty("font-color", "red");
		pps.store(out, "new font-color");
		System.out.println(pps);

	}
}
