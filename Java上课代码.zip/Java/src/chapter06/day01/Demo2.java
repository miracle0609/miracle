package chapter06.day01;

import java.util.ArrayList;

public class Demo2 {
public static void main(String[] args) {
	ArrayList <Integer>list=new ArrayList<Integer>();
	for(int i = 55; i <= 65; i++) {
		list.add(i);//������ֻ�ܴ�Ŷ����Զ�װ��
	}
	for(int i = 0; i < list.size(); i++) {
		if(list.get(i) < Integer.valueOf(60)){
			list.set(i,list.get(i)+1);
		}
	}
	System.out.println(list);
//	ArrayList list=new ArrayList();
//	for(int i = 55; i <= 65; i++) {
//		list.add(i);//������ֻ�ܴ�Ŷ����Զ�ת���ɣ�object��
//	}
//	for(int i = 0; i < list.size(); i++) {
//		if((int)list.get(i) < 60){
//			list.set(i,(int)list.get(i)+1);
//		}
//	}
//	System.out.println(list);
}
}
