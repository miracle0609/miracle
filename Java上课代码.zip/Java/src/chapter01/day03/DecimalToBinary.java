package chapter01.day03;

import edu.princeton.cs.algs4.StdOut;

//Exercise 1.1.9
public class DecimalToBinary {  //将一个数字转换为二进�?
    public static String decimalToBinary(int n) {
        String resultString = "";
        for (int i = 31; i >= 0; i--)
            resultString = resultString + (n >>> i & 1);  //将整数每�?个高位右移至相应的最低位再�?�与�?1，结果转换为字符串从左到右排列输出，依然是原来的二进�?
        return resultString;
    }

    public static void main(String[] args) {

        StdOut.println(decimalToBinary(97));
    }
}
