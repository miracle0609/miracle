package chapter01.day03;

//Exercise 1.1.1
public class PrintValue {
    public static void main(String[] args) {
        System.out.println(2.0e-6 * 100000000.1);
    }
}
