package chapter03.zuoye;


public class Consumer {
	private String consumerName;

	public String getConsumerName() {
		return consumerName;
	}

	public void setConsumerName(String consumerName) {
		this.consumerName = consumerName;
	}

	public Consumer(String consumerName) {
		super();
		this.consumerName = consumerName;
	}

	public Consumer() {
		
	}
}
