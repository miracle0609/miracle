package chapter02.day01;
public class Test2 {
	public static void main(String[] args) {
		byte a = 127;
		short b = 32767;
		int c = 2147483647;
		long d = 9223372036854775807L;
		float e = 3.4E+38f;
		double f = 1.7E+308;
		char g = 'a';
		boolean h = true;
		System.out.println("a = "+a+", b = "+b+", c = "+c);
		System.out.println("d = "+d);
		System.out.println("e = "+e);
		System.out.println("f = "+f);
		System.out.println("g = "+g);
		System.out.println("h = "+h);
		d = a;
		System.out.println("d = "+d);
		b = (short)c;
		System.out.println("b = "+b);
		System.out.println("ѧ�ţ�18080340128");
		System.out.println("������Ѧ��");
		
	}
}