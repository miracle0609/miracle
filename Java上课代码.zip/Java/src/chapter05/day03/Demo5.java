package chapter05.day03;

public class Demo5 {
	public static void main(String[] args) {

	}
}
