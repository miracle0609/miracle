package chapter05.day03;

public class Test1 {
//	public static void main(String[] args) {
//        Integer integer1 = new Integer(1);
//        Integer integer2 = new Integer(1);
//        System.out.println(integer1 == integer2);
//        System.out.println(integer1.equals(integer2));
// 
// 
//        Integer integer3 = new Integer(100);
//        Integer integer4 = new Integer(100);
//        System.out.println(integer3 == integer4);
//        System.out.println(integer3.equals(integer4));
//    }
	public static void main(String[] args) {
        Integer integer1 = 1;
        Integer integer2 = 1;
        System.out.println(integer1 == integer2);
        System.out.println(integer1.equals(integer2));
        
        Integer integer3 = 100;
        Integer integer4 = 100;
        System.out.println(integer3 == integer4);
        System.out.println(integer3.equals(integer4));
    }
}
