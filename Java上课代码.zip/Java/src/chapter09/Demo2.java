package chapter09;

class MyThread2 implements Runnable {
	@Override
	public void run() {
// TODO Auto-generated method stub
		int i = 0;
		while (i < 5) {
			System.out.println(Thread.currentThread().getName() 
					+ "��������...");
			i++;
		}
	}
}

public class Demo2 {
	public static void main(String[] args) {
		MyThread2 t=new MyThread2();
		Thread t1=new Thread(t,"�߳�1");
		t1.start();
		Thread t2=new Thread(t,"�߳�2");
		t2.start();
		new Thread(t,"�߳�3").start();
	}
	
}
