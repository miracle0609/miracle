package chapter09;

class MyThread1 extends Thread {
	@Override
	public void run() {
// TODO Auto-generated method stub
		super.run();
		int i = 0;
		while (i < 5) {
			System.out.println(Thread.currentThread().getName());
			i++;
		}
	}
}

public class Demo1 {
	public static void main(String[] args) {
		MyThread1 t1 = new MyThread1();
		t1.start();
		MyThread1 t2 = new MyThread1();
		t2.start();
	}
}
