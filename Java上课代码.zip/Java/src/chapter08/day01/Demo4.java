package chapter08.day01;

import java.awt.Button;
import java.awt.FlowLayout;
import javax.swing.JFrame;

//��ʽ����
public class Demo4 {
	public static void main(String[] args) {
		JFrame f = new JFrame("��ʽ����");
		f.setSize(600, 500);
		f.setLocation(300, 200);
		f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		f.setLayout(new FlowLayout());
		f.setLayout(new FlowLayout(FlowLayout.LEFT, 20, 20));
		f.add(new Button("��ť1"));
		f.add(new Button("��ť2"));
		f.add(new Button("��ť3"));
		f.add(new Button("��ť4"));
		f.setVisible(true);
	}
}
