package chapter08.day01;

import java.awt.BorderLayout;
import java.awt.Button;
import javax.swing.JFrame;

//�߽粼��
public class Demo3 {
	public static void main(String[] args) {
		JFrame f = new JFrame("�߽粼��");
		f.setSize(600, 500);
		f.setLocation(300, 200);
		f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
//���ô���Ϊ�߽粼�ַ�ʽ
		f.setLayout(new BorderLayout());
		f.add(new Button("��ť1"), BorderLayout.PAGE_START);
		f.add(new Button("��ť2"), BorderLayout.PAGE_END);
		f.add(new Button(" ��ť3"), BorderLayout.LINE_START);
		f.add(new Button("��ť4"), BorderLayout.CENTER);
		f.add(new Button("��ť5"), BorderLayout.LINE_END);
		f.add(new Button("��ť6"), BorderLayout.CENTER);
		f.setVisible(true);
	}
}
