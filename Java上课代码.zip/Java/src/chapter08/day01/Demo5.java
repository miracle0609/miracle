package chapter08.day01;

import java.awt.Button;
import java.awt.GridLayout;
import javax.swing.JFrame;

//���񲼾�
public class Demo5 {
	public static void main(String[] args) {
		JFrame f = new JFrame("���񲼾�");
		f.setSize(600, 500);
		f.setLocation(300, 200);
		f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		f.setLayout(new GridLayout(5, 5));
		for (int i = 1; i <= 9; i++) {
			f.add(new Button("��ť" + i));
		}
		f.setVisible(true);
	}
}