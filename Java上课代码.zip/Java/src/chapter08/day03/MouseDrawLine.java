package chapter08.day03;

import java.awt.Graphics;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.MouseMotionAdapter;

import javax.swing.JFrame;

class MouseDraw extends JFrame {
	int x, y, endX, endY;

	public MouseDraw() {
		addMouseListener(new MouseAdapter() {
			@Override
			public void mousePressed(MouseEvent e) {
				// TODO Auto-generated method stub
				super.mousePressed(e);
				x = e.getX();
				y = e.getY();
			}
		});
		addMouseMotionListener(new MouseMotionAdapter() {
			@Override
			public void mouseDragged(MouseEvent e) {
				// TODO Auto-generated method stub
				super.mouseDragged(e);
				endX = e.getX();
				endY = e.getY();
				Graphics g = getGraphics();
				g.drawLine(x, y, endX, endY);
				x = endX;
				y = endY;
			}
		});
		setSize(600, 500);
		setLocation(200, 200);
		setVisible(true);
	}

}

public class MouseDrawLine {
	public static void main(String[] args) {
		MouseDraw f = new MouseDraw();
		f.setBounds(20, 50, 600, 600);
		f.setVisible(true);
	}
}
