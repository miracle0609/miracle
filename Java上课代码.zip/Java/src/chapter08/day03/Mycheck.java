package chapter08.day03;

import java.awt.BorderLayout;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JCheckBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;

public class Mycheck extends JFrame implements ActionListener {

	JPanel panel;
	JLabel label;
	JCheckBox italic;
	JCheckBox bold;
	@Override
	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub
		int mode = 0;//plain:0,bold:1, italic:2, bold+italic:3
		if (italic.isSelected()) {
			mode += Font.ITALIC;
		}
		if (bold.isSelected()) {
			mode += Font.BOLD;
		}
		label.setFont(new Font("����", mode, 30));
	}
	public Mycheck() {
		init();
	}

	void init() {
		label = new JLabel("��ľ˹��ѧ", JLabel.CENTER);
		panel = new JPanel();
		italic = new JCheckBox("б��");
		bold = new JCheckBox("����");
		panel.add(bold);
		panel.add(italic);

//		ActionListener al = new ActionListener() {
//
//			@Override
//			public void actionPerformed(ActionEvent e) {
//				// TODO Auto-generated method stub
//				int mode = 0;
//				if (italic.isSelected()) {
//					mode += Font.ITALIC;
//				}
//				if (bold.isSelected()) {
//					mode += Font.BOLD;
//				}
//				label.setFont(new Font("����", mode, 30));
//			}
//		};
		bold.addActionListener(this);
		italic.addActionListener(this);
		add(panel, BorderLayout.PAGE_END);
		add(label);
		setBounds(200,200,600,500);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setVisible(true);

	}

	public static void main(String[] args) {
		new Mycheck();
	}

}
