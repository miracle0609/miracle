package chapter08.day03;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.ButtonGroup;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JRadioButton;

public class MyRadioButton extends JFrame implements ActionListener{
	JPanel panel,panelColor;
	JRadioButton rb1,rb2;
	@Override
	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub
		Color color=null;
		if(rb1.isSelected()) {
			color=Color.red;
		}
		if(rb2.isSelected()) {
			color=Color.yellow;
		}
		panelColor.setBackground(color);
	}
	public MyRadioButton(){
		panel = new JPanel();
		panelColor=new JPanel();
		rb1=new JRadioButton("��");
		rb2=new JRadioButton("��");
		rb1.addActionListener(this);
		rb2.addActionListener(this);
		ButtonGroup group=new ButtonGroup();
		group.add(rb1);
		group.add(rb2);
		panel.add(rb1);
		panel.add(rb2);
		add(panel,BorderLayout.PAGE_END);
		add(panelColor);
		
	}
	public static void main(String[] args) {
		MyRadioButton f=new MyRadioButton();
		f.setBounds(200, 200, 600, 600);
		f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		f.setVisible(true);
	}
}
