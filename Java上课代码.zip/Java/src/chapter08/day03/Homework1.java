package chapter08.day03;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

public class Homework1 {
	public static void main(String[] args) {
		JFrame f = new JFrame("����");
		f.setSize(300, 250);
		f.setLocation(300, 200);
		f.setLayout(new FlowLayout()); 
		JButton btn1 = new JButton("ģ̬�Ի���"); 
		JButton btn2 = new JButton("��ģ̬�Ի���");
		f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		f.add(btn1);
		f.add(btn2);
		
		JDialog dialog1 = new JDialog(f, "myDialog", true);// ����һ��ģ̬JDialog�Ի���
		JDialog dialog2 = new JDialog(f, "myDialog", false); // ����һ����ģ̬JDialog�Ի���
		
		dialog1.setSize(220, 150);                             
		dialog1.setLocation(350, 250);                       
		dialog1.setLayout(new FlowLayout());              
		JButton btn3 = new JButton("�ر�ģ̬�Ի���");        
		dialog1.add(btn3); 
		
		dialog2.setSize(220, 150);                             
		dialog2.setLocation(350, 250);                       
		dialog2.setLayout(new FlowLayout());              
		JButton btn4 = new JButton("�رշ�ģ̬�Ի���");        
		dialog2.add(btn4);
		
		// �����ť��ģ̬�Ի���
		btn1.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				dialog1.setVisible(true);
			}
		});
		// �����ť�򿪷�ģ̬�Ի���
		btn2.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				dialog2.setVisible(true);
			}
		});
		// �����ť�ر�ģ̬�Ի���
		btn3.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				dialog1.dispose();
			}
		});
		// �����ť�رշ�ģ̬�Ի���
		btn4.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				dialog2.dispose();
			}
		});
		f.setVisible(true);
	}
}