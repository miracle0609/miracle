package chapter08.day03;

import java.awt.BorderLayout;
import java.awt.event.*;
import javax.swing.*;

public class Demo3 {
	public static void main(String[] args) {
		JFrame f = new JFrame();
		f.setSize(600, 500);
		f.setLocation(300, 200);
		f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		// �����ı���
		final JTextArea area = new JTextArea(12, 30);
		area.setEditable(false);
		JScrollPane pane = new JScrollPane(area);
		// �����ı�
		final JTextField text = new JTextField(10);
		JButton btn = new JButton("����");
		// ��ǩ
		JLabel label = new JLabel();
		label.setText("������Ϣ");
		JPanel panel = new JPanel();
		panel.add(label);
		panel.add(text);
		panel.add(btn);
		btn.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				String content = text.getText();
				if (content != null && !content.equals("")) {
					area.append(content + "\n");
				} else {
					area.append("������Ϣ����Ϊ�գ�\n");
				}
				text.setText("");
			}
		});
		f.add(pane,BorderLayout.PAGE_START);
		f.add(panel,BorderLayout.PAGE_END);
		f.setVisible(true);
	}
}
