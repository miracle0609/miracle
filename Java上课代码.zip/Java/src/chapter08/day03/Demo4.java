package chapter08.day03;

import java.awt.*;

import javax.swing.*;

public class Demo4 {
	public static void main(String[] args) {
		JFrame f = new JFrame();
		f.setSize(600, 500);
		f.setLocation(300, 200);
		f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		// ����һ����ǩ��ʵ��ͼƬ
		JLabel imglabel = new JLabel();
		// ����ͼ�����
		ImageIcon icon = new ImageIcon("2.jpg");
		Image img = icon.getImage();
		img = img.getScaledInstance(300, 300, Image.SCALE_DEFAULT);
		icon.setImage(img);
		imglabel.setIcon(icon);
		JLabel label = new JLabel("��ӭ��! ", JLabel.CENTER);
		JPanel panel = new JPanel();
		panel.add(label);
		f.add(imglabel, BorderLayout.PAGE_START);
		f.add(panel, BorderLayout.PAGE_END);
		f.setVisible(true);

	}
}
