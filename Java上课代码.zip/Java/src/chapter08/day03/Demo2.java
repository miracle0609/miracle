package chapter08.day03;

import java.awt.BorderLayout;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.ScrollPaneConstants;

//��������JPanel��JSrollPane
public class Demo2 {
	public static void main(String[] args) {
		JFrame f = new JFrame();
		f.setSize(600, 500);
		f.setLocation(300, 200);
		f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		JPanel panel = new JPanel();
		panel.add(new JButton("��ť1"));
		panel.add(new JButton("��ť2"));
		panel.add(new JButton("��ť3"));
		f.add(panel,BorderLayout.PAGE_START);
		//JScrollPane pane=new JScrollPane(new JButton("��ť��"));
		JScrollPane pane=new JScrollPane();
		pane.setViewportView(new JButton("��ť��"));
		//pane.setViewportView(panel);
		
		//����ˮƽ����
		pane.setHorizontalScrollBarPolicy(ScrollPaneConstants.HORIZONTAL_SCROLLBAR_ALWAYS);
		//���ô�ֱ����
		pane.setVerticalScrollBarPolicy(ScrollPaneConstants.VERTICAL_SCROLLBAR_ALWAYS);
		f.add(pane,BorderLayout.PAGE_END);
		f.setVisible(true);
	}
}
