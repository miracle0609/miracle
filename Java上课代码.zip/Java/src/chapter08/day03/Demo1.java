package chapter08.day03;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

public class Demo1 {
	public static void main(String[] args) {
		JFrame f = new JFrame("����");
		f.setSize(300, 250);
		f.setLocation(300, 200);
		f.setLayout(new FlowLayout()); 
		JButton btn1 = new JButton("ģ̬�Ի���"); 
		JButton btn2 = new JButton("��ģ̬�Ի���");
		f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		f.add(btn1);
		f.add(btn2);
		
		JDialog dialog = new JDialog(f, "myDialog");// ����һ��JDialog�Ի���
		dialog.setSize(220, 150);                             
		dialog.setLocation(350, 250);                       
		dialog.setLayout(new FlowLayout());              
		JButton btn3 = new JButton("�رնԻ���");        
		dialog.add(btn3); 
	       
		// �����ť��ģ̬�Ի���
		btn1.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				dialog.setModal(true);
				dialog.setVisible(true);
			}
		});
		// �����ť�򿪷�ģ̬�Ի���
		btn2.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				dialog.setModal(false);
				dialog.setVisible(true);
			}
		});
		// �����ť�رնԻ���
		btn3.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				dialog.dispose();
			}
		});
	
		f.setVisible(true);
	}
}