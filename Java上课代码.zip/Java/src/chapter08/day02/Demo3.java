package chapter08.day02;

import java.awt.FlowLayout;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;

import javax.swing.JButton;
import javax.swing.JFrame;

public class Demo3 {
	public static void main(String[] args) {
		JFrame f = new JFrame("�¼�����");
		f.setSize(300, 200);
		f.setLocation(300, 200);
		f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		f.setLayout(new FlowLayout());
		JButton btn = new JButton("��ť");
		btn.addMouseListener(new MouseListener() {

			@Override
			public void mouseReleased(MouseEvent e) {
				// TODO Auto-generated method stub
				System.out.println("�ɿ����");
			}

			@Override
			public void mousePressed(MouseEvent e) {
				// TODO Auto-generated method stub
				System.out.println("��������¼�");
			}

			@Override
			public void mouseExited(MouseEvent e) {
				// TODO Auto-generated method stub
				System.out.println("�Ƴ���ť����");
			}

			@Override
			public void mouseEntered(MouseEvent e) {
				// TODO Auto-generated method stub
				System.out.println("�ƽ���ť����");
			}

			@Override
			public void mouseClicked(MouseEvent e) {
				// TODO Auto-generated method stub
				System.out.println("�����¼�");
				if (e.getButton() == MouseEvent.BUTTON1) {
					System.out.println("�������");
				}
				if (e.getButton() == MouseEvent.BUTTON2) {
					System.out.println("�м�����");
				}
				if (e.getButton() == MouseEvent.BUTTON3) {
					System.out.println("�Ҽ�����");
				}

			}
		});
		JButton btn1 = new JButton("��ť");
		btn1.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseMoved(MouseEvent e) {
				// TODO Auto-generated method stub
				super.mouseMoved(e);
				System.out.println("�ƶ�");
			}
		});
		f.add(btn1);
		f.add(btn);
		f.setVisible(true);
	}
}
