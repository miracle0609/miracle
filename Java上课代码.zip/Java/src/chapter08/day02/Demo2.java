package chapter08.day02;
import java.awt.event.WindowEvent;
import java.awt.event.WindowListener;

import javax.swing.JFrame;

public class Demo2 {
public static void main(String[] args) {
	JFrame f = new JFrame("�¼�����");
	f.setSize(300, 200);
	f.setLocation(300, 200);
	f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	f.addWindowListener(new WindowListener() {
		
		@Override
		public void windowOpened(WindowEvent e) {
			// TODO Auto-generated method stub
			System.out.println("���ڴ�");
		}
		
		@Override
		public void windowIconified(WindowEvent e) {
			// TODO Auto-generated method stub
			System.out.println("����ͼ�껯");
		}
		
		@Override
		public void windowDeiconified(WindowEvent e) {
			// TODO Auto-generated method stub
			System.out.println("ȡ������ͼ�껯");
		}
		
		@Override
		public void windowDeactivated(WindowEvent e) {
			// TODO Auto-generated method stub
			System.out.println("����ͣ��");
		}
		
		@Override
		public void windowClosing(WindowEvent e) {
			// TODO Auto-generated method stub
			System.out.println("���ڹر��С�����");
		}
		
		@Override
		public void windowClosed(WindowEvent e) {
			// TODO Auto-generated method stub
			System.out.println("���ڹر�");
		}
		
		@Override
		public void windowActivated(WindowEvent e) {
			// TODO Auto-generated method stub
			System.out.println("���ڼ���");
		}
	} );
	f.setVisible(true);
}
}
