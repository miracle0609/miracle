package chapter08.day02;

import java.awt.FlowLayout;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;

import javax.swing.JFrame;
import javax.swing.JTextField;

public class Demo4 {
	public static void main(String[] args) {
		JFrame f = new JFrame("�¼�����");
		f.setSize(300, 200);
		f.setLocation(300, 200);
		f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		f.setLayout(new FlowLayout());
		JTextField text = new JTextField(10);//10Ϊ��ʾ�Ŀ���
		text.addKeyListener(new KeyListener() {
			
			@Override
			public void keyTyped(KeyEvent e) {
				// TODO Auto-generated method stub
				
			}
			
			@Override
			public void keyReleased(KeyEvent e) {
				// TODO Auto-generated method stub
				
			}
			
			@Override
			public void keyPressed(KeyEvent e) {
				// TODO Auto-generated method stub
				System.out.println(e.getKeyChar()+"/"+e.getKeyCode());
			}
		});
		f.add(text);
		f.setVisible(true);
	}
}
