package chapter08.day04;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JTextField;

public class MyComboBox extends JPanel implements ActionListener {
	JTextField textField;
	JComboBox<String> cBox;

	@Override
	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub
		if (cBox.getSelectedIndex() != 0) {
			String str = (String) cBox.getSelectedItem();
			textField.setText(str);
		} else {
			textField.setText("");
		}

	}

	public MyComboBox() {
		textField = new JTextField(10);
		cBox = new JComboBox<String>();
		cBox.addItem("��ѡ����У�");//0
		cBox.addItem("������");//1
		cBox.addItem("�������");//2
		cBox.addItem("ĵ����");
		cBox.addItem("��ľ˹");
		add(cBox);
		cBox.addActionListener(this);
		add(textField);
	}
	public static void main(String[] args) {
		JFrame f=new JFrame();
		f.setBounds(200,200,600,500);
		f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		MyComboBox panel = new MyComboBox();
		f.add(panel);
		f.setVisible(true);
	}
	
}
