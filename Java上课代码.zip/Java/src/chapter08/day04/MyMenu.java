package chapter08.day04;

import java.awt.BorderLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JDialog;
import javax.swing.JFrame;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JPanel;

public class MyMenu extends JFrame implements ActionListener{
	JMenuBar menuBar;
	JMenu menu1, menu2;
	JMenuItem item1, item2;
	@Override
	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub
		JDialog dialog=new JDialog(this,"��",true);
		dialog.setSize(300, 200);
		dialog.setDefaultCloseOperation(JDialog.HIDE_ON_CLOSE);
		dialog.setVisible(true);

	}
	public MyMenu() {
		menuBar = new JMenuBar();
		menu1 = new JMenu("�ļ�");
		menu2 = new JMenu(" ����");
		item1 = new JMenuItem("�½�");
		item2 = new JMenuItem("��");
		menu1.add(item1);
		menu1.add(item2);
		menuBar.add(menu1);
		menuBar.add(menu2);
		add(menuBar);
		setBounds(200, 200, 600, 500);
		add(menuBar, BorderLayout.PAGE_START);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setVisible(true);
	}


	public static void main(String[] args) {
		new MyMenu();
	}
}
