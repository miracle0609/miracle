package chapter07.day01;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
//ͨ���ֽ������ƿ����ļ�
public class Demo4 {
	public static void main(String[] args) throws Exception {
		FileInputStream in = new FileInputStream("1.jpg");
		FileOutputStream out = new FileOutputStream("2.jpg");
		int len = 0;
		long beginTime = System.currentTimeMillis();
		while ((len = in.read()) != -1) {
			out.write(len);
		}
		long endTime = System.currentTimeMillis();
		System.out.println("��ʱ: " + (endTime - beginTime) + "����");
		in.close();
		out.close();

	}
}
