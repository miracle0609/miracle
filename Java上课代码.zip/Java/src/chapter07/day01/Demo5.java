package chapter07.day01;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
//ͨ���ֽ������ƿ����ļ�
public class Demo5 {
	public static void main(String[] args) throws Exception {
		FileInputStream in = new FileInputStream("1.jpg");
		FileOutputStream out = new FileOutputStream("3.jpg");
		int len = 0;
		byte[] buff = new byte[1024];
		long beginTime = System.currentTimeMillis();
		while ((len = in.read(buff)) != -1) {
			out.write(buff);
		}
		long endTime = System.currentTimeMillis();
		System.out.println("��ʱ: " + (endTime - beginTime) + "����");
		in.close();
		out.close();
	}
}
