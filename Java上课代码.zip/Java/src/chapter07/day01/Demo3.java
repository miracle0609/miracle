package chapter07.day01;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
//ͨ���ֽ�������ļ��ж�ȡ���֣��ֽ�����
public class Demo3 {
	public static void main(String[] args) throws Exception {
		FileInputStream in = new FileInputStream("write.txt");
		int len = 0;
		byte[] buff = new byte[2];
		StringBuffer str = new StringBuffer();
		while ((len = in.read(buff)) != -1 ) {
			str.append(new String(buff));
		}
		System.out.println(str.toString());
		in.close();
	}
}
