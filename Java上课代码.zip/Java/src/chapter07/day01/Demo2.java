package chapter07.day01;

import java.io.FileNotFoundException;
import java.io.FileOutputStream;

public class Demo2 {
	public static void main(String[] args) throws Exception {
		FileOutputStream out = new FileOutputStream("write.txt", true);
		String str = "hello world!����";
		out.write(str.getBytes());
		out.close();
	}
}
