package chapter07.day03;

//�ļ�������
import java.io.File;
import java.io.FilenameFilter;

class MyFilter implements FilenameFilter {
	@Override
	public boolean accept(File dir, String name) {
		// TODO Auto-generated method stub
		File currFile = new File(dir, name);
		if (currFile.isFile() && name.endsWith(".txt")) {
			return true;
		} else {
			return false;
		}
	}
}

public class Demo5 {
	public static void main(String[] args) {
		File file=new File(".");
		if(file.isDirectory()){
		//String[] fileNames=file.list(new MyFilter());
		String[] fileNames=file.list(new FilenameFilter() {
		@Override
			public boolean accept(File dir, String name) {
				File currFile=new File(dir,name);
				if(currFile.isFile() && name.endsWith(".txt")) {
					return true;
				}else{
					return false;
		}}});
			for(String name:fileNames) {
				System.out.println(name);
			}
		}
	}
}
