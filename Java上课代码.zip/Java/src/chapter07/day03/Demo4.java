package chapter07.day03;


import java.io.File;

public class Demo4 {
	public static int size = 0;
	public static void main(String[] args) {
		File file = new File("D:\\eclipse-workspace\\java\\src");
		fileDir(file);
		System.out.println(size);
	}
	public static void fileDir(File dir) {
		File[] fileNames = dir.listFiles();
		for (File file:fileNames) {
			if (file.isDirectory()) {
				fileDir(file);
			} else {
				size++;
				System.out.println(file);
			}	
		}
		
		
	}
}

