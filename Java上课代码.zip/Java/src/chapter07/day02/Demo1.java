package chapter07.day02;

import java.io.FileNotFoundException;
import java.io.FileReader;

public class Demo1 {
	public static void main(String[] args) throws Exception {
		FileReader fileReader = new FileReader("read.txt");
		int len = 0;
		while ((len = fileReader.read()) != -1) {
			System.out.print((char)len);
		}
		fileReader.close();
	}
}
