package chapter07.day02;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;


public class Demo3 {
	public static void main(String[] args) throws Exception {
		FileReader fileRead=new FileReader("read.txt");
		FileWriter fileWrite=new FileWriter("write.txt");
		int len=0;
		//ÿ�ζ�ȡһ���ַ�
//		while( (len=fileRead.read())!=-1){
//			fileWrite.write(len);
//		}
		
		//����һ���ַ����飬��Ϊ������
		char[] buff=new char[1024];
		while((len=fileRead.read(buff)) != -1) {
			fileWrite.write(buff,0,len);
		}
		fileRead.close();
		fileWrite.close();
	}
}
