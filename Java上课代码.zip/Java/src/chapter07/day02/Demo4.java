package chapter07.day02;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;

public class Demo4 {
public static void main(String[] args) throws Exception {
	BufferedReader bRead = new BufferedReader(new FileReader("read.txt"));
	BufferedWriter bWrite = new BufferedWriter(new FileWriter("write.txt"));
	String str;
	while ((str = bRead.readLine()) != null) { 
		bWrite.write(str);
		bWrite.newLine();
	}
	bWrite.flush();
	bRead.close();              
	bWrite.close();
}
}
